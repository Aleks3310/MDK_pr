package com.example.pr9_pr_21101_mysin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Syte extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_syte);
    }
}