package com.example.pr10_mysin_pr_21101;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TableRow;

public class Table extends AppCompatActivity implements View.OnClickListener {

    TableRow tr1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_table);
        tr1 = findViewById(R.id.tr1);
        tr1.setOnClickListener(this);
    }
    @Override
    public void onClick(View view) {
        Intent intent = new Intent(this, ShowItem.class);
        startActivity(intent);
    }
}