package com.example.pr_8_pr_21101_mysin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Catalog extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalog);
    }
}